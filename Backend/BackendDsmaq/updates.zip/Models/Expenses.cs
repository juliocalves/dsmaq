﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace BackendDsmaq.Models
{
    public class Expenses
    {
        public int Id { get; set; }
        public DateTime IssueDate { get; set; }
        [ForeignKey("IdSuplyer")]
        public int IdSuplyer { get; set; }
        public Suplyer Suplyer { get; set; }
        public string Document { get; set; }
        public DateTime Deadline { get; set; }
        public double InstallmentValue { get; set; }
        public int InstallmentNumber { get; set; }
        public int IdFormPayment { get; set; }
        [ForeignKey("IdFormPayment")]
        public FormPayment FormPayment { get; set; }

    }
}
