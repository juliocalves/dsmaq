﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BackendDsmaq.Models
{
    public class SuplyerGroup
    {
        public int Id { get; set; }
        public string Description { get; set; }
    }
}
